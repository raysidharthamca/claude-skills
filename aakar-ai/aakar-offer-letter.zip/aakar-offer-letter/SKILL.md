---
name: aakar-offer-letter
description: >-
  Generate a polished, Aakar AI-branded offer letter / letter of appointment as a
  self-contained HTML file plus a 2-page A4 PDF (dark-green + orange letterhead,
  embedded logo, two-phase compensation table, Swagat Ray / Director signature).
  Use this skill whenever the user wants to create, draft, regenerate, or update an
  offer letter, appointment letter, "offer of appointment", employment offer, or
  joining letter for a specific named candidate at Aakar AI — especially when they
  provide candidate ID documents (PAN/Aadhaar images), salary / stipend / CTC
  details, and offer/joining dates, or say things like "make an offer letter for
  <name>", "we hired someone, draft their offer", "put this hire on our letterhead",
  or "prior-date this offer to <date>". This is for letters addressed to one
  individual hire. For generic job postings or JDs (not addressed to a person), use
  the aakar-ai-job-posting skill instead.
---

# Aakar AI Offer Letter

Produce a hire-ready offer letter on the official Aakar AI letterhead. The deliverable is a self-contained `.html` (logo embedded as base64 — no external files) and a matching 2-page A4 `.pdf` rendered with headless Chrome, ready to email or print and sign.

The template is already built and brand-correct. Your job each time is to **gather the candidate's details and compensation, fill the placeholder tokens, adapt any optional clauses, render, and verify** — not to redesign the letter.

## Company facts (use these, never guess)

- **Company:** AAKAR AI PRIVATE LIMITED (Aakar AI Pvt Ltd)
- **CIN:** U62020OD2025PTC050160
- **Website:** aakar-ai.com · **Email:** info@aakar-ai.com
- **Phone:** **+91 81180 36131** — this is the number that belongs on the **offer letter**, and the template already carries it. Leave it as-is.
  ⚠️ Do NOT "correct" it to +91 77022 33245. That other number is the WhatsApp line used by the separate `aakar-ai-job-posting` skill; the two document types intentionally carry different numbers. Don't conflate them.
- **Address:** Areikana, Jajpur, Odisha 755008
- **Signatory:** **Swagat Ray, Director** (already in the template).
- **Brand colors:** dark green `#1F3D1C`, orange `#F58B47` (already in the template CSS).
- Roles are typically **Remote (India)** on **US Eastern Time (EST)** hours — i.e. night-shift from India (≈ 6:30 PM – 3:30 AM IST, shifting with US daylight saving). The template states this plainly; being upfront prevents offer-stage dropouts.

## Privacy: never print PAN or Aadhaar numbers

PAN and Aadhaar numbers are sensitive government identifiers. An offer letter gets emailed, forwarded, and printed, so putting those numbers on it is a real data-protection risk and the house template deliberately omits them.

- Use the Aadhaar/PAN images **only** to read the candidate's **name, parentage (S/O or D/O), and address**.
- **Do not** transcribe the 12-digit Aadhaar number or the PAN into the letter, the filename, or any saved file.
- The letter's "Joining Formalities" clause already asks the candidate to bring ID copies at joining — that is how identity gets verified, not by printing numbers up front.
- Before delivering, grep the output for those digit strings to be sure none leaked (see Verification).

## Inputs to gather

Ask for or extract these. If something is missing, ask once, concisely — don't stall on optional fields.

1. **Candidate identity** (from the Aadhaar image, name as printed there): full name, parentage (father's/guardian's name → `S/O`/`D/O`), full address.
2. **Designation** (e.g., "Associate Data Engineer (Snowflake + AI)").
3. **Dates:** offer date (the date printed on the letter) and joining/effective date. Back-dating ("prior-dated offer") is common and fine — set the offer date to the past date the user gives.
4. **Compensation:** the training stipend (amount + duration) and the post-training annual CTC. The user often gives this loosely (e.g., "10k/month stipend for 3 months, then 3 LPA"); convert it to the table below.
5. **Optional levers** (only if the user raises them): bond terms, notice periods, performance perk, shift/remote details, probation length. Otherwise the defaults below stand.

### Defaults (used unless the user overrides)

These ship in the template — state them so you never have to guess:

- **Probation:** six (6) months.
- **Notice period:** 30 days during probation, 60 days after confirmation.
- **Termination for unsatisfactory performance:** thirty (30) days' notice or pay in lieu, at the Company's discretion.
- **Performance perk:** discretionary, up to ₹5,000/month.
- **Service bond:** two (2) years; ₹50,000 if the candidate leaves before completing it.
- **Salary split:** Basic 80% / Other Allowances 20% of gross.
- **Work schedule:** fully remote (India), US-EST night shift.

## Filling the template

Copy `assets/offer_letter_template.html` to the output path (e.g. `~/Downloads/<First_Last>_Offer_Letter.html`), then replace every `{{TOKEN}}`. Tokens use Indian number formatting (e.g. `3,00,000`) and the `₹` sign is already in the template, so token **values** are bare numbers like `3,00,000`. Note `{{CANDIDATE_NAME}}` appears several times — including in the HTML `<title>` — so replace **all** occurrences, not only the ones in the letter body.

| Token | Meaning | Example (V Dinesh) |
|---|---|---|
| `{{OFFER_DATE}}` | Date printed on the letter | `June 12, 2026` |
| `{{CANDIDATE_NAME}}` | Full name as on Aadhaar | `V Dinesh` |
| `{{PARENTAGE}}` | `S/O`/`D/O` + parent name | `S/O G Venkatesh` |
| `{{CANDIDATE_ADDRESS}}` | Address; separate lines with `<br>` (no trailing `<br>`) | `17/6/384, Hasnabad, Hindupur<br>Anantapur, Andhra Pradesh – 515201` |
| `{{DESIGNATION}}` | Role title | `Associate Data Engineer (Snowflake + AI)` |
| `{{JOINING_DATE}}` | Joining / effective date | `19 June 2026` |
| `{{TRAINING_MONTHS}}` | Training length, words + digit | `three (3)` |
| `{{STIPEND_AMOUNT}}` | Monthly training stipend | `10,000` |
| `{{STIPEND_WORDS}}` | Stipend in words | `Rupees Ten Thousand Only` |
| `{{STIPEND_ANNUAL}}` | Stipend total across training | `30,000 (for 3 months)` |
| `{{TRAINING_RANGE}}` | Training rows' month-range label (= `Months 1–N`) | `Months 1–3` |
| `{{POST_TRAINING_START}}` | First post-training month (= N+1) | `4` |
| `{{PROBATION_MONTHS}}` | Probation length | `six (6)` |
| `{{CTC_ANNUAL}}` | Post-training annual CTC | `3,00,000` |
| `{{CTC_WORDS}}` | CTC in words | `Rupees Three Lakh Only` |
| `{{BASIC_MONTHLY}}` / `{{BASIC_ANNUAL}}` | Basic salary (≈80% of gross) | `20,000` / `2,40,000` |
| `{{ALLOW_MONTHLY}}` / `{{ALLOW_ANNUAL}}` | Other allowances (≈20%) | `5,000` / `60,000` |
| `{{GROSS_MONTHLY}}` / `{{GROSS_ANNUAL}}` | Gross = basic + allowances; annual = CTC | `25,000` / `3,00,000` |
| `{{PERK_AMOUNT}}` | Monthly discretionary perk cap | `5,000` |
| `{{NOTICE_PROBATION}}` / `{{NOTICE_CONFIRMED}}` | Notice period, in days | `30` / `60` |
| `{{TERMINATION_NOTICE}}` | Performance-termination notice, words + digit | `thirty (30)` |
| `{{BOND_YEARS}}` | Minimum service, words + digit | `two (2)` |
| `{{BOND_AMOUNT}}` / `{{BOND_WORDS}}` | Bond penalty (number / words) | `50,000` / `Rupees Fifty Thousand Only` |

### Computing the compensation table

The house structure is **two-phase**: a flat training stipend for the first few months, then a salaried CTC.

- **Training:** `STIPEND_ANNUAL` = stipend × training months, written like `30,000 (for 3 months)`.
- **Post-training gross monthly** = `CTC_ANNUAL ÷ 12` → `GROSS_MONTHLY`; `GROSS_ANNUAL` = `CTC_ANNUAL`.
- **Default split:** Basic ≈ **80%** of gross, Other Allowances ≈ **20%**. So for ₹25,000 gross → Basic 20,000 / Allowances 5,000; annualized 2,40,000 / 60,000. Use this split unless the user specifies their own; if they do, just make Basic + Allowances = Gross.
- Keep amounts in Indian format with thousands/lakh separators (`2,40,000`, not `240000`).
- **Timeline labels:** `TRAINING_RANGE` = `Months 1–N`, `POST_TRAINING_START` = `N+1`, where N = training months. E.g. 3 → `Months 1–3` / `4`; 2 → `Months 1–2` / `3`.

## Adapting the template (optional clauses)

The tokens cover the common case. For structural changes, edit the HTML directly — the model is trusted to do this cleanly. Common variants:

- **No service bond:** delete the `<h2>Bond Agreement</h2>` heading and the paragraph right after it. Nothing else references it.
- **No performance perk:** remove the perk sentence in the Compensation term, the `Performance Perk (discretionary)` table row, and the perk bullet under Notes.
- **No training/stipend phase** (hired straight onto full salary): remove the Training Period term, the "Training Period (Months 1–3)" section row and the Training Stipend row in the table, and the training-related Notes bullets; reword the opening so there's no "upon completion of training". The probation clause can stay.
- **Day shift / not US-EST:** edit the Work Schedule term to describe the actual hours.
- **Different durations** (training, probation, notice): just set the matching tokens — including `TRAINING_RANGE` / `POST_TRAINING_START` for the table timeline. These are tokens now, so a non-3-month training period needs no hand-editing of fixed text.

Keep the letterhead bands, logo, fonts, colors, watermark, and signature block untouched — that chrome is what makes it on-brand.

## Workflow

1. **Gather** the inputs above; extract identity from the Aadhaar image (name/parentage/address only). Convert loose comp into the table values. Confirm anything ambiguous in one short message.
2. **Copy** `assets/offer_letter_template.html` → `~/Downloads/<First_Last>_Offer_Letter.html` (or wherever the user wants it).
3. **Fill** every `{{TOKEN}}`; apply any optional-clause edits.
4. **Render:** `bash scripts/render_pdf.sh <abs path>.html <abs path>.pdf`. It finds Chrome, prints to PDF, and reports the page count.
5. **Verify** (below), then **open** the PDF (`open <file>.pdf`) and **deliver** both paths. Tell the user which fields are easy to tweak (dates, amounts), and that the candidate's acceptance Date line is intentionally blank for them to sign.

## Verification (do this every time)

- **No leftover tokens:** `grep -o '{{[A-Z_]*}}' <file>.html` must print nothing.
- **No leaked IDs:** grep the HTML for the candidate's Aadhaar and PAN digit strings — both must be absent. (Also confirm the filename has no ID numbers.)
- **Page count ~2:** the render script prints it; A4, 2 pages is the target. If it spills to 3, tighten by trimming an optional clause or shortening the address — don't shrink fonts.
- **Spot-check content:** correct name, designation, offer + joining dates, stipend, CTC, and that Basic + Allowances = Gross. Confirm the phone shows `+91 81180 36131`.
- **Look at it:** rasterize a page (`pdftoppm -png -r 120 -f 1 -l 1 <file>.pdf /tmp/ck`) and view it — letterhead bands top & bottom, logo crisp, table intact, signature block whole.

## Bundled assets

- `assets/offer_letter_template.html` — the tokenized, brand-correct letter (logo embedded as base64; correct phone; `#1F3D1C`/`#F58B47`).
- `assets/aakar_logo.png` — the official logo (already embedded in the template; kept here in case the template ever needs rebuilding).
- `scripts/render_pdf.sh` — headless-Chrome HTML→PDF renderer with page-count check.

#!/usr/bin/env bash
# Render an Aakar AI offer-letter HTML into a 2-page A4 PDF via headless Chrome.
# The HTML is self-contained (logo embedded as base64), so no other files are needed.
#
# Usage: render_pdf.sh <input.html> <output.pdf>
# Pass ABSOLUTE paths to avoid surprises with Chrome's working directory.
set -euo pipefail

IN="${1:?usage: render_pdf.sh <input.html> <output.pdf>}"
OUT="${2:?usage: render_pdf.sh <input.html> <output.pdf>}"

# Locate a Chromium-family browser. macOS default first, then common fallbacks.
CHROME=""
for c in \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  "/Applications/Chromium.app/Contents/MacOS/Chromium" \
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge" \
  "$(command -v google-chrome 2>/dev/null || true)" \
  "$(command -v chromium 2>/dev/null || true)" \
  "$(command -v chromium-browser 2>/dev/null || true)"; do
  if [ -n "$c" ] && [ -x "$c" ]; then CHROME="$c"; break; fi
done
if [ -z "$CHROME" ]; then
  echo "ERROR: no Chrome/Chromium/Edge found. Install Google Chrome or pass a browser path." >&2
  exit 1
fi

# --headless=new is the modern headless mode; --no-pdf-header-footer drops the
# default URL/date margins Chrome would otherwise stamp on each page.
"$CHROME" --headless=new --disable-gpu --no-pdf-header-footer \
  --print-to-pdf="$OUT" "$IN" 2>/dev/null

if [ ! -f "$OUT" ]; then
  echo "ERROR: render failed — $OUT was not created." >&2
  exit 1
fi

# Report the page count so the caller can confirm it landed on ~2 pages.
if command -v pdfinfo >/dev/null 2>&1; then
  PAGES="$(pdfinfo "$OUT" 2>/dev/null | awk '/^Pages:/{print $2}')"
  echo "Rendered: $OUT  (pages: ${PAGES:-unknown})"
else
  echo "Rendered: $OUT  (install poppler/pdfinfo to auto-check page count)"
fi

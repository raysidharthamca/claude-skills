---
name: linkedin-impact-post
description: Turn a technical analysis or engineering achievement (with hard, measured metrics) into a credible, numbers-forward LinkedIn post — both the visual asset (a rendered carousel PDF or a portrait one-pager PNG) AND the post copy (caption + on-visual wording). Use whenever the user wants to share a result, case study, migration, benchmark, cost saving, performance win, or build story on LinkedIn — triggers include "make this into a LinkedIn post", "turn my analysis/results into a carousel", "LinkedIn post about my project", "post this win on LinkedIn", "create a carousel for these numbers", "share this benchmark/migration on LinkedIn", or pasting metrics and asking to make them shareable. Produces a self-contained HTML visual, a high-res PNG/PDF rendered from it, and two labeled caption variants. Prefer this skill over ad-hoc post drafting or generic image generation whenever the subject is a metrics-driven technical result meant for LinkedIn. Especially apt for data/analytics/ML/platform engineers sharing measured outcomes.
---

# LinkedIn Impact Post

Turn a technical result into a post that lands with a technical audience. You
produce **two things**: a polished **visual** (a swipeable carousel or a single
portrait one-pager) and the **copy** (two caption variants + the on-visual wording).
A fixed design system keeps every post consistent and credible; a render script
turns the HTML into LinkedIn-ready images with the right fonts.

The guiding principle for this audience (engineers, data/analytics/ML leads): **the
numbers are the hero, and credibility beats hype.** Lead with hard measured results,
state how they were measured, own one honest caveat. Work the steps in order;
confirm the story outline with the user before rendering (re-rendering is cheap, but
getting the numbers and framing right first is faster).

## Step 1 — Capture the story

Gather from the conversation if it's already there; otherwise ask concisely:

- **The result**: the headline number(s) and what they mean. The single hardest,
  most defensible metric is the hero.
- **The baseline & controls**: what it's compared against and why the test is fair
  (e.g. "same data, cache off, 3 runs each", "optimized-legacy baseline not a
  strawman"). This is what makes the numbers unkillable.
- **The method**: the repeatable steps that produced the result (so it reads as
  engineering, not luck).
- **One honest caveat**: a real limitation or scope boundary.
- **Audience & angle**: who it's for and the one thing to remember.
- **Identity**: name + role for the footer; the topic to "follow for".

Summarize it back in one sentence before building: *"[old] → [new]: [the core win],
proven by [the hero number]."*

## Step 2 — Pick the format

- **Carousel** (`assets/carousel_template.html`) — the default for a *journey*:
  problem → method → proof → takeaway. Most engineering case studies fit here.
- **One-pager** (`assets/onepager_template.html`) — when the story is *one* punchy,
  self-contained result.

If unsure, choose the carousel. Tell the user which you picked and why.

## Step 3 — Pressure-test and launder the numbers

This is the step that protects the user. Before any number goes in:

- **Confirm it's real and current.** Never invent or round-up a metric. If something
  is a projection, label it a projection; if it's one pipeline, don't imply the fleet.
- **Apply confidentiality** (the user is at a fintech). Abstract internal *absolute*
  figures into relative framing (`−54%`, `3.2×`, `70→32`); strip internal
  system/table/project/team names; **flag any absolute dollar amount, volume, or
  internal identifier for the user to confirm before it goes public.** When in doubt,
  ask — don't leak. Full rules in `references/copy-playbook.md`.

## Step 4 — Build the visual

Read `references/design-system.md` first — it explains the one-accent color rule, the
fonts, the slide/one-pager grammar, and how to present numbers. Then copy the chosen
template to your working area and **edit only the regions marked `EDIT`** (don't
rewrite the CSS — that's what keeps every post consistent).

Fill in: the hook, the method steps (carousel), the stat tiles / hero number, the
comparison bars, the CTA, the footer, and the one honest caveat. Make the integrity
stat (`0` / parity) green. Use `.tchip` wordmarks or the generic sprite marks for any
tools. Show the user the content outline (or the HTML) for a quick confirm before
rendering.

## Step 5 — Render

```bash
bash scripts/setup_fonts.sh                                          # once per environment (idempotent)
python scripts/render.py one      built.html out.png                 # one-pager  -> portrait PNG (~4:5)
python scripts/render.py carousel built.html out/ --pdf carousel.pdf # carousel   -> per-slide PNGs + PDF
```

`setup_fonts.sh` installs Mulish + JetBrains Mono and ensures Playwright/Chromium.
The renderer screenshots at 2× so text stays crisp after LinkedIn re-compresses it.
**View the output before presenting** — a wrapped number or an overflowing bar is
obvious at a glance and worth a 30-second re-render.

## Step 6 — Write the captions

Read `references/copy-playbook.md` and produce **two variants** — a *Build story* and
a *Bold POV* — each following hook → context → method → proof → one honest caveat →
CTA question → 5 hashtags, ~150–250 words, emoji-light, first person. Label them by
intent so the user can choose.

## Step 7 — Present

Deliver the **visual** (PNG for a one-pager; the **PDF** + preview PNGs for a
carousel) and the **HTML** (so they can tweak and re-render), plus the two captions.
Add a one-line note on which caption suits which goal, and the posting tips that
matter: post a one-pager **PNG as a native image**; upload a carousel **PDF as a
document post**; put any link **in the first comment**. Remind them that **any logo
marks are faithful approximations, not official trademarks**, and re-flag **any
confidential absolute figure to review before posting**.

## Hard rules

- **Numbers are the hero and they must be real.** No fabrication, no rounding-up; state
  the baseline/controls; label projections as projections.
- **Exactly one honest caveat** per post; the caption never oversells past the visual.
- **One accent color** (blue); green only for the integrity stat. Don't change fonts.
- **Self-contained HTML** — inline SVG only, no hotlinked images, so the render never
  depends on the network.
- **Confidentiality first** — abstract internal absolutes, strip internal names, and
  flag anything sensitive for the user's sign-off before it's public.
- **Keep the design system intact** — edit content, not CSS (except retuning the accent
  blue for a non-Snowflake brand).

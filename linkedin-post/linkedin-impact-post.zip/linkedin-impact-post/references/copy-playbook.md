# Copy Playbook — LinkedIn Impact Post

Two kinds of copy ship with every post:

1. **On-visual text** — the few words baked into the slides/one-pager. Terse,
   declarative, number-forward.
2. **The caption** — the post body that runs beside the image/PDF. This is where
   the story breathes. Produce **2 variants** so the user can pick by intent.

The throughline of both: **numbers are the hero, the voice is a first-person build
story, and credibility beats hype.** This audience (engineers, data/analytics leads)
rewards "here's exactly what I measured and how" and punishes LinkedIn-influencer
gloss. Write like a sharp engineer showing peers something real.

## On-visual text rules

- **Hook** (cover / one-pager title): ≤ ~10 words. A claim, a tension, or a
  counter-intuitive result — not a topic label. Put the *turn* in the accent color.
  - Strong: *"I didn't migrate 45 pipelines by hand. I built the system that did."*
  - Weak: *"My dbt migration project"* (a label, no tension).
- **Numbers**: one per tile, plain-English label. Prefer `−54%`, `70→32`, `3.2×`,
  `0`. Lead with the hardest, most defensible one.
- **Phase labels** (method slide): mono, uppercase, verb-y (`PLAN`, `CONVERT`,
  `VALIDATE`). The `skill` line names the concrete how.
- **CTA**: a genuine question that invites disagreement or war-stories. Not "thoughts?".
  - Strong: *"Are you using AI to do the task — or to build the thing that does the task?"*

## Caption structure (both variants follow this skeleton)

1. **Hook line** — must land *before* LinkedIn's "…see more" cut (~2 lines / ~140
   chars). Mirror or sharpen the visual's hook. No throat-clearing.
2. **Context** — 2–3 short lines: the old setup and the friction that made it hurt.
3. **The shift / method** — name what you did plainly; 2–4 bullets using `•` or `→`.
4. **The proof** — the hard numbers, framed honestly (state the baseline / controls).
   This is the paragraph that separates this from hype.
5. **One honest caveat** — the real limitation. Mirrors the visual's caveat. Builds trust.
6. **CTA question** — invites comments (the engagement signal LinkedIn rewards).
7. **Hashtags** — exactly 5, specific to the stack and discipline.

Keep it ~150–250 words. Short lines, white space, no walls of text. Reference the
attached visual naturally ("the numbers are in the carousel / image below").

## The two variants (label them by intent)

**Variant A — Build story.** First-person narrative: the problem, how you approached
it, the measured payoff. Neutral-to-warm, teaching tone. Best for reach, peer
respect, and recruiters/leaders seeing how you think. This is the safe default.

**Variant B — Bold POV.** Opens with an opinionated take, concedes the nuance, then
makes the argument with the same numbers. Higher variance, higher ceiling — best for
debate and reach. Example opener: *"Most 'AI in data engineering' is using AI to
write SQL faster. The leverage isn't there — it's in building the system that does
the whole migration."*

## Voice & honesty rules (non-negotiable for this audience)

- **Never fabricate or round-up metrics.** Use the user's real figures. If a number
  is a projection, call it a projection. If it's one pipeline, say "one pipeline".
- **State the controls.** "cache off, same data, 3 runs each" is worth more than any
  adjective. Credibility *is* the content.
- **Exactly one honest caveat**, and don't let the caption oversell past the visual.
- **Emoji-light by default** — typographic `•` and `→`, not decorative emoji, unless
  the user's own style leans emoji. Offer to add them to taste.
- First person ("I built…", "we measured…"), active voice, concrete nouns.

## Cadence & the anti-hype kill list

The fastest way to lose this audience is to *sound* like a LinkedIn influencer. The
tells are predictable — name them so you can route around them:

- **Announcement throat-clearing**: "I'm thrilled/humbled/excited to announce…", "Big
  news!", "I've been quiet, but…". Open on the result, not on your feelings about it.
- **Hype adjectives doing a number's job**: "game-changing", "massive", "incredible",
  "10x'd" (when it wasn't literally 10×). A real figure (`−54%`) is louder than any
  superlative — let the number carry the weight and delete the adjective.
- **Vague payoff**: "drove significant impact", "moved the needle", "unlocked value".
  Say *what* moved, *by how much*, measured *how*.
- **Engagement-bait CTAs**: "Thoughts? 👇", "Agree?", "Who else??". Ask a specific
  question a working engineer would actually stop to answer.

Cadence matters as much as word choice. Vary sentence length — a punchy four-word
line next to a longer one reads like a person thinking, not a press release. Favor
concrete nouns over abstractions ("the nightly ledger rebuild", not "the process").
The gut check: read it back in your head — if it sounds like an engineer showing a
peer something real, ship it; if it sounds like a brand, cut until it doesn't.

## Confidentiality (the user is at a fintech — default to discreet)

- **Abstract internal absolute figures.** Favor relative framing: `−54%`, `3.2×`,
  `70→32 min`. A per-unit figure the user has cleared (e.g. "~$65K/yr on one
  pipeline") is fine; **program-wide spend, total volumes, or internal $ totals are
  not** — keep them as percentages.
- **Strip internal names**: system/table/schema/project/codenames, ticket IDs, team
  names. Generalize ("a core financial-ledger pipeline", not the table name).
- **Flag, don't decide.** If any absolute dollar amount, customer/volume figure, or
  internal identifier seems load-bearing, surface it and ask the user to confirm
  before it goes public. Better to ask than to leak.

## Posting mechanics (include the one tip that matters)

- **Carousel** → upload the **PDF** as a LinkedIn *document* post (it renders as
  swipeable pages). Square 1080² pages are correct.
- **One-pager** → post the **PNG as a native image** (don't attach it as a link —
  native images get far more reach). Portrait ~4:5 maximizes feed real estate.
- Put any **article/repo link in the first comment**, not the post body (links in the
  body suppress reach).
- The **first 2 lines are everything** — they're all most people see before "…more".

## Mini-templates

**A — Build story**
> I didn't [do the hard thing] by hand. I built the system that did it.
>
> For years, [old setup] meant [the friction]. It worked — but [the cost].
>
> So I [the method], in repeatable steps:
> • [step 1] → [step 2]
> • [step 3] → [step 4]
>
> Proven on the hardest case first, measured honestly ([controls]):
> • [metric 1] • [metric 2] • [integrity stat]
>
> One honest caveat: [the real limitation].
>
> [Sharp CTA question]?
>
> #Tag1 #Tag2 #Tag3 #Tag4 #Tag5

**B — Bold POV**
> Unpopular take: [the contrarian claim about the field].
>
> [The common approach] isn't wrong — it's just not where the leverage is. [One
> sentence conceding the nuance.]
>
> Here's what actually moved the needle:
> • [the real lever]
> • [why it compounds]
>
> The numbers, measured honestly ([controls]):
> • [metric 1] • [metric 2] • [integrity stat]
>
> Caveat I'll own: [the real limitation].
>
> [Sharp CTA question]?
>
> #Tag1 #Tag2 #Tag3 #Tag4 #Tag5

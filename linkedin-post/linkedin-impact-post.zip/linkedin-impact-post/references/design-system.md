# Design System — LinkedIn Impact Post

The two files in `assets/` are the source of truth for styling. **Copy a template
and edit only the regions marked `EDIT`** — don't rewrite the `<style>` block. This
keeps every post visually consistent, which is the whole point of a reusable skill.
This doc explains the grammar so your content edits stay coherent.

## The look in one line

A calm, light, "engineering-credible" sheet: white rounded cards on a soft paper
gradient, navy headlines, **one** bright accent (Snowflake-blue `#29b5e8`), and
mono-spaced uppercase micro-labels that read like instrument readouts. The numbers
are huge; everything else gets out of their way.

## Color convention (load-bearing — don't break it)

It looks premium because it is disciplined: **one accent color, used only for the
win.** Resist adding a second.

- **Navy** (`--navy #163a5c`) — headlines, structure, the things you read first.
- **Slate** (`--slate #5b6e80`) — the "before"/legacy/old, muted body, secondary
  text. The old world should visually *recede*.
- **Accent blue** (`--sf #29b5e8`, deep `--sf-deep #0b6aa2`) — the "after", the
  result, the single thing you want remembered. Used on the hero number, the
  accent half of the hook, the "new" bars, badges, the CTA border.
- **Green** (`--good #1f9d77`) — reserve for an *integrity* stat: `0` defects,
  row-for-row parity, zero deviation. It reads as "trustworthy", not "another color".
- **Amber** (`#e0a13c`) — only if you must flag an honest gap/workaround. Optional.

To retarget a non-Snowflake brand, you may retune `--sf / --sf-deep / --sf-tint /
--sf-tint2` to that brand's blue/teal — but keep navy + slate + the one-accent rule.

## Typography (don't change the fonts)

- **Mulish** — everything display and body. Weights do the work: 900 for hooks and
  numbers, 800 for labels, 500–600 for body. `setup_fonts.sh` installs it.
- **JetBrains Mono** — eyebrows, phase tags, metric micro-labels, tool chips. Always
  uppercase with wide letter-spacing. This mono texture is what signals "built by an
  engineer who measures things". Use it sparingly, as seasoning.

## Two formats — pick by story shape

| Format | File | Use when | Output |
|---|---|---|---|
| **Carousel** | `carousel_template.html` | The story is a *journey* (problem → method → proof → takeaway). Most engineering case studies. | 4 square (1080²) slides + a PDF you upload as a LinkedIn document post |
| **One-pager** | `onepager_template.html` | The story is *one* punchy, self-contained result. | One portrait (~4:5) PNG |

When in doubt, prefer the carousel — it earns more dwell time, and the "swipe"
mechanic suits a build narrative. Use the one-pager when there's really one number.

## Carousel slide grammar (4 slides, flex 3–6)

1. **Cover / Hook** — eyebrow (`CASE STUDY · OLD → NEW`), a scroll-stopping hook
   with exactly one line in `.accent`, a progression subpill (`start → lever →
   outcome`), and your name + `swipe →`. This is the slide that wins the click.
2. **Method** — a numbered step rail (`.step`, 4–5 phases). `phase` = mono label,
   `skill` = the concrete how, `desc` = one line. Shows it was *repeatable*, not luck.
3. **Proof** — a 2×2 `.grid` of `.stat` tiles. Big number + plain label. Make one
   tile `.good` (the integrity stat). A `.micro` line carries secondary proof.
4. **Chart + CTA** — a `.chart` of 2–3 bar groups (old=slate, new=blue, with a
   `.delta`), a one-line `.scale` (how it generalized), a `.cta` question, and a
   follow footer.

Add a slide by duplicating a `<section class="slide">`; the renderer picks up every
`.slide` automatically.

## One-pager grammar (top → bottom)

Eyebrow → title (the claim) → subtitle (the credible one-liner) → **`.hero` band**
(the single biggest number, 100px+) → **`.tiles`** (3 supporting stats) → optional
**`.chart`** (delete if the tiles say enough) → footer with **one honest caveat** +
your name. The hero number is the hook; everything else corroborates it.

## How to present numbers (the hero)

- **One number per tile**, set huge (Mulish 900). The label underneath is plain
  English, not jargon. Don't stack two metrics in one tile.
- **Comparisons** use the bar grammar: slate bar = before/old at 100% height, blue
  bar = after/new scaled proportionally, with a `.delta` (`−54%`) underneath. Keep
  bar heights *truthful* — a 46% result is a 46%-height bar, not a token stub.
- **Integrity stat** (`0` / parity / zero deviation) goes green. It's the most
  persuasive tile because it pre-empts "but is it correct?".
- **Confidential absolutes** → use relative framing (`−54%`, `3.2×`, `70→32`) instead
  of internal dollar/volume figures. See `references/copy-playbook.md` for the rule.

## Logos & marks

The sprite ships generic marks (`ic-generic`, `ic-spark`, `ic-flow`) recolored via
`currentColor`. For a tool with a clean reproducible mark you may add a `<symbol>`;
for everything else use a `.tchip` wordmark (lowercase product name). Marks are
**faithful approximations, not official trademarks** — say so before the user posts
on a company channel. Never hotlink image URLs: the file must render offline.

## Render

```bash
bash scripts/setup_fonts.sh                                   # once per environment
python scripts/render.py one      built.html out.png          # one-pager  (~4:5 portrait)
python scripts/render.py carousel built.html out/ --pdf carousel.pdf   # carousel -> PNGs + PDF
```

`setup_fonts.sh` installs Mulish + JetBrains Mono and ensures Playwright/Chromium.
The renderer aborts the blocked Google-Fonts request and screenshots at 2× so text
stays crisp after LinkedIn re-compresses it. **Always view the output before
presenting** — a number that wrapped or a bar that overflowed is obvious at a glance.

## Don'ts

- Don't introduce a second accent color. One blue. (Green only for the integrity stat.)
- Don't crowd: ≤ 4 stat tiles, ≤ 5 method steps, ≤ 3 bar groups per chart.
- Don't change the fonts — they're what the renderer installs.
- Don't overclaim: every post carries exactly one honest caveat.
- Don't bake confidential absolute figures into the art without the user's sign-off.

#!/usr/bin/env python3
"""
Render LinkedIn post visuals from self-contained HTML using Playwright Chromium.

The design relies on Mulish + JetBrains Mono. Run scripts/setup_fonts.sh once
before rendering (fonts resolve by family name from the local cache — no network
needed at render time; the blocked Google-Fonts request is aborted).

Two modes:

  one        A single portrait one-pager -> one full-page PNG (~4:5).
               python render.py one  built.html  out.png  [--width 1000] [--scale 2]

  carousel   One HTML file containing N elements with class "slide" (each sized
             1080x1080) -> one square PNG per slide, then a multi-page PDF
             (this is what you upload as a LinkedIn "document"/carousel post).
               python render.py carousel built.html outdir/ [--name slide]
                                          [--size 1080] [--scale 2] [--pdf carousel.pdf]

Why element screenshots for the carousel: keeping every slide in ONE html file
means they share one <style> block, so the design system can't drift slide to
slide. The renderer screenshots each .slide element at a fixed square size.
"""
import argparse
import glob
import os
import pathlib
import sys


def _launch(p):
    return p.chromium.launch(args=["--no-sandbox", "--force-color-profile=srgb"])


def _block_webfonts(page):
    # Don't wait on the blocked Google Fonts request; local fonts resolve by family name.
    page.route("**://fonts.googleapis.com/**", lambda r: r.abort())
    page.route("**://fonts.gstatic.com/**", lambda r: r.abort())


def _report(path):
    size = os.path.getsize(path)
    try:
        from PIL import Image
        with Image.open(path) as im:
            w, h = im.size
        print(f"  wrote {path}  ({size:,} bytes, {w}x{h} px)")
    except Exception:
        print(f"  wrote {path}  ({size:,} bytes)")


def render_one(input_html: str, output_png: str, width: int = 1240, scale: int = 2) -> None:
    from playwright.sync_api import sync_playwright
    src = pathlib.Path(input_html).resolve().as_uri()
    with sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": width, "height": 900}, device_scale_factor=scale)
        _block_webfonts(page)
        page.goto(src, wait_until="domcontentloaded")
        page.wait_for_timeout(1200)  # let layout + entrance animations settle
        page.screenshot(path=output_png, full_page=True)
        browser.close()
    _report(output_png)


def render_carousel(input_html: str, outdir: str, name: str = "slide",
                    size: int = 1080, scale: int = 2, pdf: str = None) -> None:
    from playwright.sync_api import sync_playwright
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    src = pathlib.Path(input_html).resolve().as_uri()
    pngs = []
    with sync_playwright() as p:
        browser = _launch(p)
        page = browser.new_page(viewport={"width": size, "height": size}, device_scale_factor=scale)
        _block_webfonts(page)
        page.goto(src, wait_until="domcontentloaded")
        page.wait_for_timeout(1000)
        slides = page.query_selector_all(".slide")
        if not slides:
            browser.close()
            sys.exit("No elements with class 'slide' found. For a single image use mode 'one'.")
        for i, el in enumerate(slides, 1):
            png = str(out / f"{name}-{i}.png")
            el.screenshot(path=png)
            pngs.append(png)
            _report(png)
        browser.close()

    if pdf:
        from PIL import Image
        Image.init()  # register codecs PIL's PDF writer needs for RGB pages
        imgs = [Image.open(p).convert("RGB") for p in pngs]
        # resolution so a 2x square renders to a clean 10in PDF page (LinkedIn-friendly)
        dpi = (size * scale) / 10.0
        imgs[0].save(pdf, save_all=True, append_images=imgs[1:], resolution=dpi)
        _report(pdf)
        print(f"Carousel: {len(pngs)} slides -> {pdf}")
    else:
        print(f"Carousel: {len(pngs)} slide PNGs in {outdir}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="mode", required=True)

    a = sub.add_parser("one", help="single portrait one-pager -> PNG")
    a.add_argument("input_html")
    a.add_argument("output_png")
    a.add_argument("--width", type=int, default=1000,
                   help="canvas width; 1000 keeps a metric one-pager portrait (~4:5). Widen for taller content.")
    a.add_argument("--scale", type=int, default=2)

    c = sub.add_parser("carousel", help="multi-slide HTML -> per-slide PNGs + PDF")
    c.add_argument("input_html")
    c.add_argument("outdir")
    c.add_argument("--name", default="slide")
    c.add_argument("--size", type=int, default=1080)
    c.add_argument("--scale", type=int, default=2)
    c.add_argument("--pdf", default=None)

    args = ap.parse_args()
    if args.mode == "one":
        render_one(args.input_html, args.output_png, args.width, args.scale)
    else:
        render_carousel(args.input_html, args.outdir, args.name, args.size, args.scale, args.pdf)

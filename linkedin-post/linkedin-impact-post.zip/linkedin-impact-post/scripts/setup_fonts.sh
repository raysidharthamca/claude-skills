#!/usr/bin/env bash
# Install the two fonts the design uses (Mulish, JetBrains Mono) plus the
# Playwright Chromium the renderer drives. The container can't reach
# fonts.googleapis.com, but both fonts are open source on GitHub (reachable).
# Once installed, Chromium resolves them by family name (`font-family:'Mulish'`
# / `'JetBrains Mono'`) with no network at render time.
#
# Run this ONCE per environment before rendering. Safe to re-run (idempotent).
set -e

FONT_DIR="$HOME/.fonts"
mkdir -p "$FONT_DIR"

if ! fc-list 2>/dev/null | grep -qi 'mulish'; then
  echo "Downloading Mulish (variable)…"
  curl -fsSL -o "$FONT_DIR/Mulish.ttf" \
    "https://raw.githubusercontent.com/google/fonts/main/ofl/mulish/Mulish%5Bwght%5D.ttf"
fi

if ! fc-list 2>/dev/null | grep -qi 'jetbrains'; then
  echo "Downloading JetBrains Mono (variable)…"
  curl -fsSL -o "$FONT_DIR/JetBrainsMono.ttf" \
    "https://raw.githubusercontent.com/JetBrains/JetBrainsMono/master/fonts/variable/JetBrainsMono%5Bwght%5D.ttf"
fi

fc-cache -f "$FONT_DIR" >/dev/null 2>&1 || true

echo "Installed families:"
fc-list | grep -iE 'mulish|jetbrains' | sort -u

# Renderer dependency: Playwright + Chromium. Both are no-ops if already present.
echo "Ensuring Playwright + Chromium…"
python3 -c "import playwright" 2>/dev/null || pip install playwright --break-system-packages >/dev/null 2>&1 || true
python3 -m playwright install chromium >/dev/null 2>&1 || true

echo "Setup complete."
